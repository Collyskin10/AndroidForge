# Preparación de sincronización familiar

Para habilitar el uso desde varios teléfonos será necesario:

1. Crear un proyecto Firebase.
2. Registrar la app Android con el identificador `com.hogarcontrol.app`.
3. Añadir el archivo `google-services.json` dentro de `app/`.
4. Activar Firebase Authentication (correo electrónico).
5. Crear Cloud Firestore.
6. Definir hogares, miembros, invitaciones y movimientos.
7. Aplicar reglas que limiten el acceso a miembros autenticados del hogar correspondiente.
8. Probar que usuarios externos no puedan leer ni modificar datos.

No usar reglas abiertas ni credenciales de prueba en producción.
