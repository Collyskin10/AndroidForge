# HogarControl — Android 0.1.0

Proyecto inicial nativo para Android, escrito en Kotlin y Jetpack Compose.

## Incluido
- Panel con balance, ingresos y gastos registrados.
- Alta de ingresos y gastos con descripción e importe.
- Categoría editable.
- Listado de movimientos.
- Guardado local en el teléfono.
- Navegación inicial para Inicio, Movimientos, Recibos, Estadísticas y Ahorro.

## Limitación importante de esta entrega
Esta primera versión guarda los movimientos localmente en cada teléfono. **Todavía no sincroniza los datos entre familiares ni incluye inicio de sesión.** La sincronización requiere configurar un proyecto Firebase propiedad del usuario, activar Authentication y Firestore y aplicar reglas de seguridad por hogar. No se deben introducir datos reales sensibles hasta completar esa fase.

## Abrir y ejecutar
1. Instala Android Studio actualizado.
2. Descomprime este ZIP.
3. Abre la carpeta `HogarControl` desde Android Studio.
4. Usa JDK 17 y Android SDK 35.
5. Espera a que Gradle sincronice y pulsa Run con un emulador o móvil conectado.

## Próximas fases
1. Cuentas familiares, invitaciones y sincronización segura en la nube.
2. Recibos periódicos y avisos.
3. Presupuestos por categoría y objetivos de ahorro.
4. Gráficos mensuales, trimestrales, semestrales y anuales.
5. Exportación Excel y PDF.
6. Pruebas, privacidad y preparación de publicación.

No hay conexión bancaria ni se solicitan credenciales bancarias.
