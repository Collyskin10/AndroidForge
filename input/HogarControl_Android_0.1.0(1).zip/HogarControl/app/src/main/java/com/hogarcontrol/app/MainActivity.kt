package com.hogarcontrol.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale

private val Navy = Color(0xFF14283D)
private val Teal = Color(0xFF168C80)
private val Green = Color(0xFF16845B)
private val Red = Color(0xFFD65B61)

data class Movement(val description: String, val amount: Double, val income: Boolean, val category: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HogarControl() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HogarControl() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("hogarcontrol", 0) }
    val movements = remember {
        mutableStateListOf<Movement>().apply {
            val raw = prefs.getString("items", "") ?: ""
            raw.lines().filter { it.count { c -> c == '|' } == 3 }.forEach { line ->
                val p = line.split("|")
                add(Movement(p[0], p[1].toDoubleOrNull() ?: 0.0, p[2] == "1", p[3]))
            }
        }
    }
    var showAdd by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    val money = NumberFormat.getCurrencyInstance(Locale("es", "ES"))
    val income = movements.filter { it.income }.sumOf { it.amount }
    val expenses = movements.filterNot { it.income }.sumOf { it.amount }

    MaterialTheme(colorScheme = lightColorScheme(primary = Teal, secondary = Navy)) {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("HogarControl", color = Navy, fontWeight = FontWeight.Bold)
                        Text("Economía familiar", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                })
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }, containerColor = Teal, contentColor = Color.White) {
                    Icon(Icons.Default.Add, contentDescription = "Añadir")
                }
            },
            bottomBar = {
                NavigationBar {
                    listOf("Inicio", "Movimientos", "Recibos", "Estadísticas", "Ahorro").forEachIndexed { i, label ->
                        val icon = when (i) {
                            0 -> Icons.Default.Home
                            1, 2 -> Icons.Default.ReceiptLong
                            3 -> Icons.Default.Analytics
                            else -> Icons.Default.Savings
                        }
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, contentDescription = label) }, label = { Text(label) })
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(18.dp)) {
                when (tab) {
                    0 -> {
                        Text("Resumen familiar", style = MaterialTheme.typography.titleMedium)
                        Card(Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            colors = CardDefaults.cardColors(containerColor = Navy)) {
                            Column(Modifier.padding(20.dp)) {
                                Text("Balance registrado", color = Color.LightGray)
                                Text(money.format(income - expenses), color = Color.White,
                                    style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(12.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Ingresos  ${money.format(income)}", color = Color(0xFF79D5B4))
                                    Text("Gastos  ${money.format(expenses)}", color = Color(0xFFFFA4A4))
                                }
                            }
                        }
                        Text("Movimientos recientes", style = MaterialTheme.typography.titleMedium)
                        MovementList(movements.takeLast(5).reversed(), money)
                    }
                    1 -> {
                        Text("Todos los movimientos", style = MaterialTheme.typography.titleLarge)
                        MovementList(movements.reversed(), money)
                    }
                    2 -> InfoPage("Recibos", "Aquí organizaremos recibos mensuales, trimestrales y anuales.")
                    3 -> InfoPage("Estadísticas", "Ingresos: ${money.format(income)}\nGastos: ${money.format(expenses)}\nLos gráficos históricos llegarán en la siguiente fase.")
                    else -> InfoPage("Presupuestos y ahorro", "Aquí añadiremos límites por categoría y objetivos de ahorro.")
                }
            }
        }
        if (showAdd) {
            AddMovement(
                onClose = { showAdd = false },
                onSave = { item ->
                    movements.add(item)
                    prefs.edit().putString("items", movements.joinToString("\n") {
                        "${it.description.replace("|", "/")}|${it.amount}|${if (it.income) 1 else 0}|${it.category}"
                    }).apply()
                    showAdd = false
                }
            )
        }
    }
}

@Composable
private fun MovementList(items: List<Movement>, money: NumberFormat) {
    if (items.isEmpty()) {
        Text("Todavía no hay movimientos. Pulsa + para añadir el primero.", color = Color.Gray,
            modifier = Modifier.padding(top = 18.dp))
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items) { item ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(item.description, fontWeight = FontWeight.SemiBold)
                            Text(item.category, color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                        }
                        Text((if (item.income) "+" else "−") + money.format(item.amount),
                            color = if (item.income) Green else Red, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoPage(title: String, message: String) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(message, color = Color.Gray)
        Spacer(Modifier.height(12.dp))
        Text("En desarrollo", color = Teal, fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddMovement(onClose: () -> Unit, onSave: (Movement) -> Unit) {
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Alimentación") }
    var income by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Añadir movimiento") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !income, onClick = { income = false; category = "Alimentación" }, label = { Text("Gasto") })
                    FilterChip(selected = income, onClick = { income = true; category = "Nómina" }, label = { Text("Ingreso") })
                }
                OutlinedTextField(description, { description = it }, label = { Text("Descripción") }, singleLine = true)
                OutlinedTextField(amount, { amount = it }, label = { Text("Importe en euros") }, singleLine = true)
                OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val value = amount.trim().replace(",", ".").toDoubleOrNull()
                if (description.isNotBlank() && value != null && value > 0) {
                    onSave(Movement(description.trim(), value, income, category.trim()))
                }
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancelar") } }
    )
}
